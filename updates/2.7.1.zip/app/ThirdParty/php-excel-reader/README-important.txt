SpreadsheetReader_XLSX.php
Added custom code in line #373
To fix error: XMLReader::open(): Empty string supplied as input
Ref: https://github.com/nuovo/spreadsheet-reader/issues/59