<?php
$execute_ci4_file = "app/Controllers/Execute_ci4.php";
if (file_exists($execute_ci4_file)) {
	unlink($execute_ci4_file);
}
